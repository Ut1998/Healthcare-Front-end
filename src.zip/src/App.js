import logo from "./logo.svg";
import "./App.css";
import LoginComponent from "./LoginComponent";
import DiagnosticCenterComponent from "./Components/DiagnosticCenterComponent";
import ListCenters from "./Components/ListCenters";
import Home from "./Home";
import { BrowserRouter as Router } from "react-router-dom";
import { Route, Switch } from "react-router-dom";
import CreateCenterComponent from "./Components/CreateCenterComponent";

function App() {
  return (
    <div className="App">
      <Router>
        <Home />
        <div className="container">
          <Switch>
            <Route path="/logincomponent" component={LoginComponent}></Route>
            <Route path="/addCenter">
              <CreateCenterComponent />
            </Route>
          </Switch>
        </div>
        <br />
        <LoginComponent />
        {/* <DiagnosticCenterComponent /> */}
        <ListCenters />
        <CreateCenterComponent />
      </Router>
    </div>
  );
}

export default App;
