import React, { Component } from "react";

class LoginComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      role: "Patient",
      isSubmitting: false,
      errorMessage: null,
    };
  }

  handleInputChange = (event) => {
    this.setState({
      ...this.state,
      [event.target.name]: event.target.value,
    });
  };

  handleFormSubmit = (event) => {
    this.setState({
      ...this.state,
      isSubmitting: true,
      errorMessage: null,
    });
  };

  render() {
    return (
      <div className="login-container">
        <div className="container">
          <form onSubmit={this.handleFormSubmit}>
            <table>
              <h1>Login</h1>
              <tr>
                <label htmlFor="username">
                  <td>Username</td>
                  <td>
                    <input
                      type="text"
                      value={this.state.username}
                      onChange={this.handleInputChange}
                      name="username"
                      id="username"
                    />
                  </td>
                </label>
              </tr>
              <tr>
                <label htmlFor="password">
                  <td>Password</td>
                  <td>
                    <input
                      type="password"
                      value={this.state.password}
                      onChange={this.handleInputChange}
                      name="password"
                      id="password"
                    />
                  </td>
                </label>
              </tr>
              <tr>
                <label html for="role">
                  <td>Role</td>
                  <td>
                    <input
                      type="radio"
                      name="role"
                      id="role"
                      value={this.state.role}
                      onChange={this.handleInputChange}
                    />
                    Patient
                  </td>
                  <td>
                    <input
                      type="radio"
                      name="role"
                      id="role"
                      value={this.state.role}
                      onChange={this.handleInputChange}
                    />
                    Admin
                  </td>
                </label>
              </tr>
              {this.state.errorMessage && (
                <span className="form-error">{this.state.errorMessage}</span>
              )}
              <button value="submit" id="login">
                Login
              </button>
            </table>
          </form>
        </div>
      </div>
    );
  }
}

export default LoginComponent;
