import React, { Component } from "react";

class LoginComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      isSubmitting: false,
      errorMessage: null,
    };
  }

  handleInputChange = (event) => {
    this.setState({
      ...this.state,
      [event.target.name]: event.target.value,
    });
  };

  handleFormSubmit = (event) => {
    event.preventDefault();
    this.setState({
      ...this.state,
      isSubmitting: true,
      errorMessage: null,
    });
  };

  render() {
    return (
      <div className="login-container">
        <div className="card">
          <div className="container">
            <form onSubmit={this.handleFormSubmit}>
              <h1>Login</h1>

              <label htmlFor="username">
                Username
                <input
                  type="text"
                  value={this.state.username}
                  onChange={this.handleInputChange}
                  name="username"
                  id="username"
                />
              </label>
              <br />
              <label htmlFor="password">
                Password
                <input
                  type="password"
                  value={this.state.password}
                  onChange={this.handleInputChange}
                  name="password"
                  id="password"
                />
              </label>
              <br />
              {this.state.errorMessage && (
                <span className="form-error">{this.state.errorMessage}</span>
              )}

              <button value="submit" id="login">
                Login
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default LoginComponent;
