import React, { Component } from "react";
import DiagnosticCenterService from "../Services/DiagnosticCenterService";

export class ListCenters extends Component {
  constructor(props) {
    super(props);

    this.state = {
      centers: [],
    };
  }

  componentDidMount = () => {
    DiagnosticCenterService.viewAllCenters().then((res) => {
      this.setState({ centers: res.data });
    });
  };

  render() {
    return (
      <div>
        <h1 className="text-center">Diagnostic Center List</h1>
        <div className="row"></div>
        <table className="table table-striped table-bordered">
          <thead>
            <tr>
              <th>DiagnosticCenter Name</th>
              <th>DiagnosticCenter Contact</th>
              <th>DiagnosticCenter Address</th>
              <th>DiagnosticCenter Email</th>
              <th>Service offered</th>
            </tr>
          </thead>
          <tbody>
            {this.state.centers.map((center) => (
              <tr key={center.centerId}>
                <td>{center.name}</td>
                <td>{center.contactNo}</td>
                <td>{center.address}</td>
                <td>{center.contactEmail}</td>
                <td>{center.servicesOffered}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default ListCenters;
