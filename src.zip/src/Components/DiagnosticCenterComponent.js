// import React, { Component } from "react";

// class DiagnosticCenterComponent extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       name: '',
//       contact: '',
//       email: '',
//       address: '',
//     };
//   }

//   render() {
//     return (
//       <div>
//
//             {/* <tbody>
//               {this.state.diagnosticCenter.map((center) => (
//                 <tr key={diagnosticCenter.centerId}>
//                   <td>{diagnosticCenter.name}</td>
//                   <td>{diagnosticCenter.email}</td>
//                   <td>{diagnosticCenter.address}</td>
//                   <td>{diagnosticCenter. contact}</td>
//                   <td>{diagnosticCenter.servicesoffered}</td>
//                 </tr>
//               ))}
//             </tbody> */}
//           </table>
//         </div>
//       </div>
//     );
//   }
// }

// export default DiagnosticCenterComponent;

import Axios from "axios";
import React from "react";

class DiagnosticCenterComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: 0,
      name: "",
      contact: "",
      email: "",
      address: "",
      services: "",
      resp: "",
    };
    this.onSub = this.onSub.bind(this);
  }

  onSub(e) {
    e.preventDefault();
    var url =
      "http://localhost:8080/addCenter/" +
      this.state.id +
      "/" +
      this.state.name +
      "/" +
      this.state.contact +
      "/" +
      this.state.email +
      "/" +
      this.state.address +
      "/" +
      this.state.services;
    Axios.post(url).then((j) =>
      this.setState({ resp: JSON.stringify(j.data) })
    );
  }

  render() {
    return (
      <div>
        <form onSubmit={this.onSub}>
          <table className="table table-bordered">
            <tr>
              <td>ID</td>
              <td>
                <input
                  type="number"
                  name="id"
                  onChange={(e) => this.setState({ eid: e.target.value })}
                />
              </td>
            </tr>
            <tr>
              <td>Name</td>
              <td>
                <input
                  type="text"
                  name="name"
                  onChange={(e) => this.setState({ ename: e.target.value })}
                />
              </td>
            </tr>
            <tr>
              <td>Contact</td>
              <td>
                <input
                  type="text"
                  name="contact"
                  onChange={(e) => this.setState({ salary: e.target.value })}
                />
              </td>
            </tr>
            <tr>
              <td>Email</td>
              <td>
                <input
                  type="text"
                  name="email"
                  onChange={(e) => this.setState({ salary: e.target.value })}
                />
              </td>
            </tr>
            <tr>
              <td>Address</td>
              <td>
                <input
                  type="text"
                  name="address"
                  onChange={(e) => this.setState({ salary: e.target.value })}
                />
              </td>
            </tr>
            <tr>
              <td>Servicesoffered</td>
              <td>
                <input
                  type="text"
                  name="services"
                  onChange={(e) => this.setState({ salary: e.target.value })}
                />
              </td>
            </tr>
            <tr>
              <td>
                <input type="submit" value="Send" className="btn btn-success" />
              </td>
              <td>
                <input type="reset" value="Cancel" className="btn btn-danger" />
              </td>
            </tr>
          </table>
        </form>
        <div className="alert alert-success">{this.state.resp}</div>
      </div>
    );
  }
}

export default DiagnosticCenterComponent;
