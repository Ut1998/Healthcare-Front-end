import React, { Component } from "react";
import { Link, Route, Switch } from "react-router-dom";
import LoginComponent from "./LoginComponent";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <nav class="navbar navbar-dark bg-dark mt-2">
          <h1 class="navbar-brand">HealthCare</h1>
          <form class="form-inline">
            <button class="btn btn-outline-primary mr-sm-2" type="submit">
              SignUp
            </button>
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
              <Link to="/logincomponent">Log In</Link>
            </button>
            <Switch path="/logincomponent" component={LoginComponent} />
          </form>
        </nav>
      </div>
    );
  }
}

export default Home;
