import React, { Component } from "react";
import { createBrowserHistory as history } from "history";
import FooterComponent from "./FooterComponent";

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
    this.onAddCenter = this.onAddCenter.bind(this);
  }

  onClick = () => {
    this.props.history.push("/LoginComponent");
    // let path = "/LoginComponent";
    // history.push(path);
  };

  onAddCenter() {
    this.props.history.push("/addCenter");
  }

  render() {
    return (
      <div>
        <nav class="navbar navbar-dark bg-dark mt-1">
          <h1 class="navbar-brand">HealthCare</h1>
          <form class="form-inline">
            <button
              className="btn btn-primary mr-sm-2"
              onClick={this.onAddCenter}
            >
              Add Center
            </button>
            <button className="btn btn-outline-primary mr-sm-2" type="submit">
              SignUp
            </button>
            <button
              class="btn btn-outline-success my-2 my-sm-0"
              onClick={this.onClick}
            >
              Log In
            </button>
          </form>
        </nav>
        <FooterComponent />
      </div>
    );
  }
}

export default Home;
