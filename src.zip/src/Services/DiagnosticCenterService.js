import axios from "axios";

const CENTER_API_BASE_URL = "http://localhost:8080/health/";

class DiagnosticCenterServiceService {
  viewAllCenters() {
    return axios.get(CENTER_API_BASE_URL + "retrievecenters" + "/" + "all");
  }

  // addDiagnosticCenter(diagnosticCenter) {
  //   return axios.post(CENTER_API_BASE_URL, diagnosticCenter);
  // }

  // getCenterById(centerId) {
  //   return axios.get(
  //     CENTER_API_BASE_URL + "/" + retrievecenters + "/" + centerId
  //   );
  // }

  // updateDiagnosticCenter(centerId, diagnosticCenter) {
  //   return axios.put(
  //     CENTER_API_BASE_URL + "/" + updatecenter + "/" + centerId,
  //     diagnosticCenter
  //   );
  // }

  // deleteEmployee(employeeId) {
  //   return axios.delete(CENTER_API_BASE_URL + "/" + employeeId);
  // }
}

export default new DiagnosticCenterServiceService();
